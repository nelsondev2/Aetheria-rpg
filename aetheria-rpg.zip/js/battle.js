/* ============================================================
   AETHERIA — Sistema de combate por turnos (estilo JRPG lateral)
   ============================================================ */
'use strict';

const Battle = {
  active: false,
  enemies: [], party: [], queue: [], turnIdx: 0,
  phase: 'intro',           // intro|cmd|target|skill|item|anim|msg|end
  msgQueue: [], msgTimer: 0,
  anim: null, popups: [], shake: 0, flash: null,
  cmdSel: 0, targetSel: 0, subSel: 0, actor: null,
  bb: 'bb_field', onEnd: null, isBoss: false, bgY: 0,

  /* ---------- Inicio ---------- */
  start(enemyKeys, opts={}) {
    if (this.active) return;
    if (!G.party.length || G.state==='title' || G.state==='intro') return;
    this.active = true;
    G.state = 'battle';
    this.isBoss = !!opts.boss;
    this.onEnd = opts.onEnd || null;
    this.enemies = enemyKeys.map((k, i) => {
      const def = ENEMIES[k.key];
      const lvBoost = opts.lvBoost || 0;
      return {
        key: k.key, name: def.name, sprite: def.sprite,
        hp: def.hp + lvBoost*8, maxHp: def.hp + lvBoost*8,
        atk: def.atk + lvBoost, def: def.def, mag: def.mag + (lvBoost>>1), agi: def.agi,
        exp: def.exp, gold: def.gold, skills: def.skills||[], weak: def.weak,
        boss: def.boss, drop: def.drop, phases: def.phases||1, phase: 1,
        x: 0, y: 0, baseX: 0, baseY: 0, dead: false, hurtT: 0, atkT: 0,
        buffs: {}, slot: i,
      };
    });
    this.party = G.party.map(h => ({ hero: h, dead: h.hp<=0, hurtT:0, atkT:0, guarding:false, buffs:{}, slot:0 }));
    this.bb = G.map ? G.map.def.bb : 'bb_field';
    this.phase = 'intro';
    this.introT = 0;
    this.queue = [];
    this.popups = [];
    this.shake = 0;
    this.bgY = 0;
    AudioSys.playTrack(this.isBoss ? 'boss' : 'battle');
    AudioSys.sfx('encounter');
    UI.hideAll();
    this.layoutPositions();
    this.turnIdx = 0;
    setTimeout(() => { this.phase = 'msg'; this.msg('¡Aparecen ' + this.enemies.map(e=>e.name).join(', ') + '!'); }, 650);
  },

  layoutPositions() {
    // Enemigos a la izquierda
    const es = this.enemies.filter(e => !e.dead);
    const n = this.enemies.length;
    this.enemies.forEach((e, i) => {
      const col = i % 2, row = Math.floor(i/2);
      e.baseX = 130 + col*220 + (n<=2 ? 90 : 0);
      e.baseY = 150 + row*130;
      e.x = e.baseX + 900; e.y = e.baseY;
      e.t = Math.random()*6;
    });
    // Grupo a la derecha (más arriba para no quedar tras el panel de órdenes)
    this.party.forEach((p, i) => {
      p.x = 620 + i*78; p.y = 252 + (i%2)*44;
    });
  },

  /* ---------- Turnos ---------- */
  aliveEnemies() { return this.enemies.filter(e => !e.dead); },
  aliveParty() { return this.party.filter(p => !p.dead); },

  buildQueue() {
    this.queue = [
      ...this.aliveParty().map(p => ({ side:'party', ref:p, agi:statsOf(p.hero).agi })),
      ...this.aliveEnemies().map(e => ({ side:'enemy', ref:e, agi:e.agi })),
    ].sort((a,b) => b.agi - a.agi);
    this.turnIdx = 0;
  },

  nextTurn() {
    // limpiar guards
    this.party.forEach(p => p.guarding = false);
    if (this.aliveEnemies().length === 0) return this.victory();
    if (this.aliveParty().length === 0) return this.defeat();
    if (this.turnIdx >= this.queue.length) { this.buildQueue(); }
    const t = this.queue[this.turnIdx++];
    if (!t || (t.side==='party' ? (t.ref.dead) : t.ref.dead)) return this.nextTurn();
    this.actor = t;
    if (t.side === 'party') {
      const h = t.ref.hero;
      if (h.hp <= 0) return this.nextTurn();
      this.phase = 'cmd';
      this.cmdSel = 0;
      UI.showBattleCmd(this);
    } else {
      this.enemyAct(t.ref);
    }
  },

  /* ---------- Acciones del jugador ---------- */
  playerAct(action) {
    const me = this.actor.ref;
    const h = me.hero;
    const st = statsOf(h);
    if (action.type === 'attack') {
      this.phase = 'target';
      this.targetSel = 0;
      UI.showBattleTargets(this, this.aliveEnemies(), 'attack');
    }
    else if (action.type === 'skill') {
      const sk = SKILLS[action.id];
      if (sk.type==='restore' || sk.type==='revive' || (sk.type==='buff' && sk.target!=='self')) {
        this.pendingSkill = action.id;
        const targets = sk.target==='party' ? null : this.party.filter(p=>!p.dead || sk.type==='revive');
        if (!targets) return this.execSkillParty(action.id);
        this.phase = 'target';
        this.targetSel = 0;
        UI.showBattleTargets(this, targets, 'skill');
      } else if (sk.target === 'all' || sk.target === 'enemies' || sk.target === 'self') {
        this.execSkill(action.id, sk.target==='self' ? me : null);
      } else {
        this.pendingSkill = action.id;
        this.phase = 'target';
        this.targetSel = 0;
        UI.showBattleTargets(this, this.aliveEnemies(), 'skill');
      }
    }
    else if (action.type === 'item') {
      const it = ITEMS[action.id];
      if (it.type==='damage' && it.target==='all') return this.useItem(action.id, null);
      if (it.type==='damage') {
        this.pendingItem = action.id;
        this.phase = 'target';
        UI.showBattleTargets(this, this.aliveEnemies(), 'item');
      } else {
        const targets = this.party.filter(p => !p.dead);
        this.pendingItem = action.id;
        this.phase = 'target';
        UI.showBattleTargets(this, targets, 'item');
      }
    }
    else if (action.type === 'guard') {
      me.guarding = true;
      this.phase = 'anim';
      this.anim = { kind:'guard', t:0, who:me };
      this.msg(`${h.name} adopta una postura defensiva.`);
    }
    else if (action.type === 'flee') {
      const chance = 0.5 + (st.agi - (this.aliveEnemies()[0]?.agi||8))*0.03;
      if (!this.isBoss && Math.random() < clamp(chance, .25, .95)) {
        AudioSys.sfx('flee');
        this.msg('¡El grupo escapó del combate!');
        this.phase = 'anim';
        this.anim = { kind:'flee', t:0 };
      } else {
        this.msg(this.isBoss ? '¡No puedes escapar de este enemigo!' : '¡No lograron escapar!');
        this.phase = 'msg'; this.msgTimer = 0.9;
      }
    }
  },

  execAttack(attackerRef, target) {
    const st = statsOf(attackerRef.hero);
    const atk = st.atk;
    this.doPhysDamage(attackerRef, target, atk, 1.0, {});
  },

  doPhysDamage(attackerRef, target, atk, mult, opts) {
    const est = target.side==='party' ? statsOf(target.hero) : target;
    const def = target.side==='party' ? (target.guarding ? est.def*2 : est.def) : enemyStat(target,'def');
    let dmg = Math.max(1, Math.floor((atk*2 - def) * mult * rand(0.9, 1.12)));
    const crit = Math.random() < 0.08;
    if (crit) dmg = Math.floor(dmg * 1.75);
    this.phase = 'anim';
    this.anim = { kind:'attack', t:0, who:attackerRef, target, dmg, crit, applied:false, opts };
  },

  execSkill(id, selfTarget) {
    const me = this.actor.ref;
    const h = me.hero, st = statsOf(h);
    const sk = SKILLS[id];
    h.mp -= sk.mp;
    this.phase = 'anim';
    if (sk.type === 'restore') {
      this.anim = { kind:'skill', t:0, who:me, skill:id, target: this.pendingTarget || me, applied:false };
    } else if (sk.type === 'revive') {
      this.anim = { kind:'skill', t:0, who:me, skill:id, target: this.pendingTarget, applied:false };
    } else if (sk.type === 'buff' || sk.type === 'debuff') {
      this.anim = { kind:'skill', t:0, who:me, skill:id, target: this.pendingTarget || me, applied:false };
    } else if (sk.target === 'all' || sk.target === 'enemies') {
      this.anim = { kind:'aoe', t:0, who:me, skill:id, applied:false };
    } else {
      this.anim = { kind:'skill', t:0, who:me, skill:id, target:this.pendingTarget || this.aliveEnemies()[0], applied:false };
    }
  },

  execSkillParty(id) { // habilidades de grupo aliado (massHeal)
    const me = this.actor.ref;
    const h = me.hero;
    const sk = SKILLS[id];
    h.mp -= sk.mp;
    this.phase = 'anim';
    this.anim = { kind:'aoe_heal', t:0, who:me, skill:id, applied:false };
  },

  useItem(id, target) {
    removeItem(id, 1);
    const it = ITEMS[id];
    this.phase = 'anim';
    this.anim = { kind:'item', t:0, who:this.actor.ref, item:id, target, applied:false };
  },

  /* ---------- Acción enemiga ---------- */
  enemyAct(e) {
    const alive = this.aliveParty();
    if (alive.length === 0) return;
    // elige habilidad
    let skId = null;
    if (e.skills.length && Math.random() < (e.boss ? 0.65 : 0.4)) skId = pick(e.skills);
    const target = pick(alive);
    this.phase = 'anim';
    this.anim = { kind:'enemy', t:0, who:e, skill:skId, target, applied:false };
  },

  /* ---------- Daño aplicado (desde anim) ---------- */
  applyDamage(target, dmg, opts={}) {
    const isParty = target.side === 'party';
    const h = target.hero;
    // debilidad elemental se aplica ANTES del daño
    let final = dmg;
    if (!isParty && opts.elem && target.weak === opts.elem) {
      final = Math.floor(dmg * 1.5);
      this.popup(target, '¡DÉBIL!', '#ff9e5e');
    }
    if (isParty) {
      h.hp = clamp(h.hp - final, 0, h.maxHp);
      if (h.hp <= 0) { target.dead = true; AudioSys.sfx('faint'); }
    } else {
      target.hp = clamp(target.hp - final, 0, target.maxHp);
      target.hurtT = 0.35;
      if (target.hp <= 0) {
        target.dead = true;
        G.monstersSlain++;
        this.popup(target, '¡Derrotado!', '#ffd75e');
      }
    }
    this.popup(target, (opts.crit?'¡':'')+final+(opts.crit?'!':''), opts.crit ? '#ffde5e' : (isParty ? '#ff7a6e' : '#fff'), opts.crit);
    this.shake = Math.min(14, 4 + final/18);
    AudioSys.sfx(opts.crit ? 'crit' : 'hit');
  },

  popup(ref, text, color='#fff', big=false) {
    const isParty = ref.side==='party';
    const x = isParty ? ref.x + 24 : ref.x + 70;
    const y = (isParty ? ref.y - 50 : ref.y) + (Math.random()*10-5);
    this.popups.push({ x, y, text, color, life:1, age:0, big });
  },

  msg(text, dur=1.6) {
    this.msgQueue.push({ text, dur });
    if (this.phase !== 'msg') this.phase = 'msg';
    // el primer mensaje en cola empieza a mostrar su duración;
    // los siguientes la toman al pasar a cabeza (ver update)
    if (this.msgQueue.length === 1) this.msgTimer = dur;
  },

  /* Adelanta el mensaje actual (teclado Z/Enter o toque en pantalla) */
  skipMsg() {
    if (this.phase !== 'msg' || !this.msgQueue.length) return;
    this.msgQueue.shift();
    const nx = this.msgQueue[0];
    if (nx) this.msgTimer = nx.dur || 1.6;
    else { this.msgTimer = 0; this.nextTurn(); }
  },

  /* ---------- Fin de combate ---------- */
  victory() {
    AudioSys.playTrack('victory');
    let exp = 0, gold = 0;
    const drops = [];
    this.enemies.forEach(e => { exp += e.exp; gold += e.gold; if (e.drop && Math.random()<0.5) drops.push(e.drop); });
    this.phase = 'victory';
    this.victoryT = 0;
    this.victoryData = { exp, gold, drops, levels:[] };
    // aplicar
    G.gold += gold;
    drops.forEach(d => addItem(d, 1));
    // progreso de la misión de limos
    if (G.quests.some(q => q.id==='slimes' && !q.done)) {
      G.flags.slimeCount = (G.flags.slimeCount||0) + 1;
      if (G.flags.slimeCount >= 3) {
        G.flags.slimeQuestDone = true;
        UI.toast('📜 ¡Vuelve con el alcalde Bram a por tu recompensa!');
      } else {
        UI.toast('📜 Misión: grupos derrotados ' + G.flags.slimeCount + '/3');
      }
    }
    this.party.forEach(p => {
      if (p.dead) return;
      const h = p.hero;
      h.exp += exp;
      while (h.exp >= expNext(h.lv) && h.lv < 50) {
        h.lv++;
        const old = { ...statsOf(h) };
        h.maxHp = statsOf(h).hp; h.maxMp = statsOf(h).mp;
        h.hp = h.maxHp; h.mp = h.maxMp;
        const def = HEROES[h.id];
        def.skills.forEach(([sk, l]) => {
          if (l === h.lv && !h.skills.includes(sk)) { h.skills.push(sk); (this.victoryData.levels.push({ name:h.name, skill:sk })); }
        });
        this.victoryData.levels.push({ name:h.name });
        AudioSys.sfx('levelup');
      }
    });
  },

  defeat() {
    this.phase = 'defeat';
    this.defeatT = 0;
    AudioSys.stopMusic();
  },

  finish() {
    this.active = false;
    G.state = 'play';
    // los buffs/debuffs no persisten tras el combate
    this.party.forEach(p => { delete p.hero.buffs; });
    UI.hideBattle();
    UI.showHUD(true);
    AudioSys.playTrack(G.map.music);
    if (this.onEnd) { const f = this.onEnd; this.onEnd = null; f(); }
    if (this.postVictory) { const f = this.postVictory; this.postVictory = null; f(); }
  },

  /* ---------- Render ---------- */
  render() {
    const c = ctx2d;
    const W = canvas.width, H = canvas.height;
    // fondo
    const bg = Assets.img(this.bb);
    this.bgY += 0.06;
    if (bg) {
      const sc = Math.max(W/bg.width, H/bg.height) * 1.02;
      const bw = bg.width*sc, bh = bg.height*sc;
      const ox = Math.sin(this.bgY*0.15)*8;
      c.drawImage(bg, (W-bw)/2 + ox, (H-bh)/2, bw, bh);
    } else { c.fillStyle = '#1a2a1a'; c.fillRect(0,0,W,H); }
    // viñeta
    const vg = c.createRadialGradient(W/2, H/2, H/3, W/2, H/2, W/1.4);
    vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(10,5,25,.5)');
    c.fillStyle = vg; c.fillRect(0,0,W,H);

    // shake
    c.save();
    if (this.shake > 0) { this.shake *= 0.86; if (this.shake < 0.4) this.shake = 0; c.translate(rand(-this.shake, this.shake), rand(-this.shake, this.shake)); }

    // enemigos
    for (const e of this.enemies) {
      if (e.dead) continue;
      e.t += 0.016;
      const bob = Math.sin(e.t*2 + e.slot)*4;
      const im = Assets.img(e.sprite);
      if (im) {
        const scale = e.boss ? 1.9 : 1.5;
        const w = im.width*scale, h = im.height*scale;
        let x = e.x - w/2, y = e.y - h + 40 + bob;
        if (e.hurtT > 0) { e.hurtT -= 0.016; if (Math.floor(e.hurtT*20)%2===0) c.globalAlpha = 0.45; }
        // sombra
        c.fillStyle = 'rgba(0,0,0,.3)';
        c.beginPath(); c.ellipse(e.x, e.y+40, w*0.36, 9, 0, 0, Math.PI*2); c.fill();
        if (this.anim && this.anim.kind==='flashwhite' && this.anim.target===e) { /* leave */ }
        c.drawImage(im, x, y, w, h);
        c.globalAlpha = 1;
      }
      // barra HP enemigo (solo si dañado o boss)
      if (e.hp < e.maxHp || e.boss) {
        const bw = e.boss ? 160 : 90;
        const bx = e.x - bw/2, by = e.y + 46;
        c.fillStyle = 'rgba(10,10,20,.75)';
        c.fillRect(bx-1, by-1, bw+2, 8);
        c.fillStyle = '#e8434a';
        c.fillRect(bx, by, bw * (e.hp/e.maxHp), 6);
      }
      if (e.boss) {
        c.font = '700 13px sans-serif'; c.textAlign = 'center';
        c.fillStyle = '#ffd75e';
        c.fillText(e.name, e.x, e.y+70);
      }
    }

    // grupo (sprites de pie, mirando a la izquierda)
    for (const p of this.party) {
      const h = p.hero;
      const im = Assets.img(HEROES[h.id].walk);
      if (im) {
        const x = p.x, y = p.y;
        c.fillStyle = 'rgba(0,0,0,.3)';
        c.beginPath(); c.ellipse(x+24, y+52, 16, 6, 0, 0, Math.PI*2); c.fill();
        let sy = 3*18; // fila left
        let sx = 16;
        if (!p.dead) {
          const walk = Math.floor(G.time*6)%2===0 ? 16 : 0;
          c.drawImage(im, walk, sy, 16, 18, x, y, 48, 54);
          if (p.hurtT > 0) { p.hurtT -= 0.016; }
        } else {
          c.globalAlpha = 0.35;
          c.drawImage(im, 16, 3*18, 16, 18, x, y+14, 48, 54);
          c.globalAlpha = 1;
        }
      }
    }

    // animación actual
    this.renderAnim(c);

    // popups de daño
    for (const p of this.popups) {
      p.age += 0.016;
      const a = 1 - p.age/p.life;
      const yy = p.y - p.age*36;
      c.globalAlpha = a;
      c.font = (p.big?'900 30px':'800 22px') + ' "Segoe UI", sans-serif';
      c.textAlign = 'center';
      c.lineWidth = 4; c.strokeStyle = 'rgba(0,0,0,.8)';
      c.strokeText(p.text, p.x, yy);
      c.fillStyle = p.color;
      c.fillText(p.text, p.x, yy);
      c.globalAlpha = 1;
    }
    this.popups = this.popups.filter(p => p.age < p.life);
    c.restore();

    // flash blanco al golpear
    if (this.flashT > 0) { this.flashT -= 0.016; c.fillStyle = `rgba(255,255,255,${this.flashT*1.8})`; c.fillRect(0,0,W,H); }

    // mensajes
    if (this.phase === 'msg' || this.phase==='intro' || this.phase==='victory' || this.phase==='defeat') {
      UI.drawBattleMsg(c);
    }
  },

  renderAnim(c) {
    const a = this.anim;
    if (!a) return;
    a.t += 0.016;
    const T = a.t;

    if (a.kind === 'attack' || a.kind === 'skill' || a.kind === 'item' || a.kind === 'enemy' || a.kind==='aoe' || a.kind==='aoe_heal') {
      // embestida del actor
      if (a.kind !== 'aoe' && a.kind !== 'aoe_heal') {
        const who = a.who;
        const isParty = who.side === 'party';
        if (a.kind === 'enemy') {
          // enemigo embiste hacia la derecha
          const prog = Math.min(1, T/0.25);
          who.x = who.baseX + prog * 160;
          if (T > 0.38) {
            if (!a.applied) { this.applyEnemyHit(a); a.applied = true; }
            who.x = who.baseX + Math.max(0, 1 - (T-0.38)/0.25) * 160;
          }
        } else {
          // miembro del grupo embiste a la izquierda
          const dist = a.kind==='attack' ? 130 : 90;
          const prog = Math.min(1, T/0.22);
          const baseX = 620 + this.party.indexOf(who)*78;
          if (T < 0.22) who.x = baseX - prog*dist*0.6;
          else if (T < 0.4) who.x = baseX - dist*(0.6 + 0.4*Math.sin((T-0.22)/0.18*Math.PI));
          else who.x = baseX - dist*Math.max(0, 1-(T-0.4)/0.22);
          if (T > 0.30 && !a.applied) { this.applyPartyHit(a); a.applied = true; }
        }
      } else {
        if (T > 0.45 && !a.applied) { this.applyAoeHit(a); a.applied = true; }
        if (a.kind==='aoe' && T > 0.1) {
          // lluvia de partículas sobre enemigos
          if (Math.random()<0.6) {
            const e = pick(this.aliveEnemies());
            if (e) Particles.spawn({ x:e.x+rand(-60,60), y:e.y-rand(0,90), vx:rand(-20,20), vy:rand(60,160), life:.5, size:4, color:this.skillColor(SKILLS[a.skill]?.anim) });
          }
        }
        if (a.kind==='aoe_heal' && T > 0.1 && Math.random()<0.5) {
          const p = pick(this.aliveParty());
          if (p) Particles.spawn({ x:p.x+rand(-10,40), y:p.y+rand(-10,10), vx:0, vy:-60, life:.7, size:4, color:'#8ff0a0' });
        }
      }
      // efectos de habilidad sobre el objetivo
      if (a.kind==='skill' && a.target && !a.applied) {
        const sk = SKILLS[a.skill];
        const tgt = a.target;
        if (tgt && T > 0.25) {
          const x = tgt.side==='party' ? tgt.x+16 : tgt.x;
          const y = tgt.side==='party' ? tgt.y+10 : tgt.y;
          this.castEffect(sk.anim, x, y);
        }
      }
    }

    if (a.kind === 'guard') { if (T > 0.7) { this.anim = null; this.endTurn(); } return; }
    if (a.kind === 'flee') { if (T > 1.0) { this.anim = null; this.finish(); } return; }

    // duraciones por tipo
    const durs = { attack:0.75, skill:0.9, item:0.75, enemy:0.85, aoe:1.05, aoe_heal:0.9 };
    if (T > (durs[a.kind] || 0.8)) { this.anim = null; this.endTurn(); }
  },

  castEffect(anim, x, y) {
    const colors = { fire:'#ff8a3d', ice:'#7ad8ff', thunder:'#ffe95e', holy:'#fff3b0', dark:'#b06ee8', heal:'#8ff0a0', buff:'#ffd75e', slash:'#ffffff', wave:'#cfe8ff', meteor:'#ff6a3d' };
    const col = colors[anim] || '#fff';
    for (let i=0;i<14;i++) Particles.spawn({ x:x+rand(-24,24), y:y+rand(-24,10), vx:rand(-70,70), vy:rand(-130,-20), grav:160, life:rand(.3,.7), size:rand(2,5), color:col });
    if (anim==='thunder') { this.flashT = 0.25; AudioSys.sfx('thunder'); }
    else if (anim==='fire'||anim==='meteor') AudioSys.sfx('fire');
    else if (anim==='ice') AudioSys.sfx('ice');
    else if (anim==='holy') AudioSys.sfx('holy');
    else if (anim==='dark') AudioSys.sfx('dark');
    else if (anim==='heal') AudioSys.sfx('heal');
  },

  skillColor(anim) { return ({ fire:'#ff8a3d', ice:'#7ad8ff', thunder:'#ffe95e', holy:'#fff3b0', dark:'#b06ee8' })[anim] || '#cfe8ff'; },

  applyPartyHit(a) {
    const attacker = a.who;
    const st = statsOf(attacker.hero);
    if (a.kind === 'attack') {
      this.doPhysApply(attacker, a.target, st.atk, 1.0, {});
    } else if (a.kind === 'skill') {
      const sk = SKILLS[a.skill];
      if (sk.type === 'restore') {
        const tgt = a.target; const h = tgt.hero;
        const st2 = statsOf(h);
        const amt = Math.min(sk.value + st2.mag, st2.hp - h.hp + sk.value);
        h.hp = clamp(h.hp + sk.value, 0, h.maxHp);
        this.popup(tgt, '+'+sk.value, '#8ff0a0');
        AudioSys.sfx('heal');
      } else if (sk.type === 'revive') {
        const tgt = a.target; const h = tgt.hero;
        if (h.hp <= 0) {
          h.hp = Math.floor(h.maxHp * sk.value);
          tgt.dead = false;
          this.popup(tgt, '¡Revive!', '#fff3b0');
          AudioSys.sfx('holy');
        }
      } else if (sk.type === 'buff' || sk.type === 'debuff') {
        const map = { atk:'ATQ', def:'DEF', mag:'MAG', agi:'AGI', all:'TODAS' };
        if (sk.target === 'enemies') {
          // debuff en área a todos los enemigos (p.ej. Rugido de Guerra)
          this.aliveEnemies().forEach(e => {
            e.buffs = e.buffs || {};
            e.buffs[sk.stat] = { mult: sk.mult, turns: sk.turns };
            this.popup(e, '▼ ' + (map[sk.stat]||'?'), '#ffd75e');
          });
        } else {
          const tgt = a.target || attacker;
          const hb = tgt.hero;
          hb.buffs = hb.buffs || {};
          hb.buffs[sk.stat] = { mult: sk.mult, turns: sk.turns };
          this.popup(tgt, (sk.type==='debuff'?'▼ ':'▲ ')+map[sk.stat], '#ffd75e');
        }
        AudioSys.sfx('buff');
      } else {
        // ataque elemental/mágico a un enemigo
        const tgt = a.target;
        if (tgt && !tgt.dead) {
          let dmg;
          if (sk.type === 'phys') dmg = Math.max(1, Math.floor((st.atk*2 - tgt.def) * sk.power * rand(.9,1.12)));
          else dmg = Math.max(1, Math.floor((st.mag*2.2 - tgt.mag*0.5) * sk.power * rand(.9,1.12)));
          const weak = sk.elem && tgt.weak === sk.elem;
          if (weak) dmg = Math.floor(dmg*1.5);
          if (sk.execute && tgt.hp < tgt.maxHp*0.25) dmg *= 2;
          tgt.hp = clamp(tgt.hp - dmg, 0, tgt.maxHp);
          tgt.hurtT = .35;
          this.popup(tgt, dmg+'', weak?'#ff9e5e':'#fff', weak||!!sk.execute);
          if (weak) this.popup(tgt, '¡DÉBIL!', '#ff9e5e');
          this.shake = 8; this.flashT = 0.12;
          this.castEffect(sk.anim, tgt.x, tgt.y-20);
          AudioSys.sfx(sk.type==='phys' ? 'hit' : ({fire:'fire',ice:'ice',thunder:'thunder',holy:'holy',dark:'dark'})[sk.elem] || 'hit');
          if (tgt.hp <= 0) { tgt.dead = true; G.monstersSlain++; this.popup(tgt,'¡Derrotado!','#ffd75e'); }
        }
      }
    } else if (a.kind === 'item') {
      const it = ITEMS[a.item];
      const tgt = a.target;
      if (it.type === 'damage') {
        if (tgt && !tgt.dead) {
          const dmg = it.target==='all' ? it.value : it.value;
          if (it.target==='all') { this.aliveEnemies().forEach(e => this.applyDamage(e, dmg, {elem:it.elem})); }
          else this.applyDamage(tgt, dmg, {elem:it.elem});
        }
      } else if (tgt) {
        const h = tgt.hero;
        if (it.type==='heal') { h.hp = clamp(h.hp+it.value,0,h.maxHp); this.popup(tgt,'+'+it.value,'#8ff0a0'); AudioSys.sfx('heal'); }
        else if (it.type==='mp') { h.mp = clamp(h.mp+it.value,0,h.maxMp); this.popup(tgt,'+'+it.value+' PM','#7ec2ff'); AudioSys.sfx('heal'); }
        else if (it.type==='full') { h.hp=h.maxHp; h.mp=h.maxMp; this.popup(tgt,'¡TODO!','#fff3b0'); AudioSys.sfx('heal'); }
        else if (it.type==='revive') { if (h.hp<=0){ h.hp=Math.floor(h.maxHp*it.value); tgt.dead=false; this.popup(tgt,'¡Revive!','#fff3b0'); AudioSys.sfx('holy'); } }
      }
    }
  },

  doPhysApply(attacker, target, atk, mult, opts) {
    const def = target.side==='party' ? (target.guarding ? statsOf(target.hero).def*2 : statsOf(target.hero).def) : enemyStat(target,'def');
    let dmg = Math.max(1, Math.floor((atk*2 - def) * mult * rand(0.9, 1.12)));
    const crit = Math.random() < 0.09;
    if (crit) dmg = Math.floor(dmg*1.75);
    target.hp = clamp(target.hp - dmg, 0, target.maxHp);
    target.hurtT = .35;
    this.popup(target, (crit?'¡':'')+dmg+(crit?'!':''), crit?'#ffde5e':'#fff', crit);
    this.shake = Math.min(14, 4+dmg/16); this.flashT = 0.08;
    AudioSys.sfx(crit?'crit':'hit');
    Particles.spawn({ x:target.x+rand(-20,20), y:target.y+rand(-30,10), vx:rand(-90,90), vy:rand(-120,-30), grav:300, life:.4, size:3, color:'#fff' });
    if (target.hp <= 0) { target.dead = true; G.monstersSlain++; this.popup(target,'¡Derrotado!','#ffd75e'); }
  },

  applyEnemyHit(a) {
    const e = a.who;
    const target = a.target;
    if (!target || target.dead) return;
    const h = target.hero;
    let sk = a.skill ? SKILLS[a.skill] : null;
    const st = statsOf(h);
    const eAtk = enemyStat(e,'atk'), eMag = enemyStat(e,'mag');
    if (!sk) {
      // ataque normal
      let dmg = Math.max(1, Math.floor((eAtk*2 - (target.guarding ? st.def*2 : st.def)) * rand(.9,1.1)));
      h.hp = clamp(h.hp - dmg, 0, h.maxHp);
      target.hurtT = .35;
      this.popup(target, dmg+'', '#ff7a6e');
      this.shake = 8;
      AudioSys.sfx('hit');
      if (h.hp <= 0) { target.dead = true; AudioSys.sfx('faint'); }
    } else if (sk.type === 'phys') {
      let dmg = Math.max(1, Math.floor((eAtk*2 - (target.guarding?st.def*2:st.def)) * sk.power * rand(.9,1.1)));
      h.hp = clamp(h.hp - dmg, 0, h.maxHp);
      target.hurtT = .35;
      this.popup(target, dmg+'', '#ff7a6e');
      this.shake = 10;
      AudioSys.sfx('hit');
      if (h.hp <= 0) { target.dead = true; AudioSys.sfx('faint'); }
    } else if (sk.type === 'magic') {
      let dmg = Math.max(1, Math.floor((eMag*2.2 - st.mag*0.4) * sk.power * rand(.9,1.1)));
      if (sk.target==='all') { this.aliveParty().forEach(p => this.magicHitEnemy(e, p, sk)); }
      else {
        h.hp = clamp(h.hp - dmg, 0, h.maxHp);
        target.hurtT = .35;
        this.popup(target, dmg+'', '#e08aff');
        this.castEffect(sk.anim, target.x+16, target.y+10);
        AudioSys.sfx(({fire:'fire',ice:'ice',thunder:'thunder',dark:'dark',holy:'holy'})[sk.elem]||'hit');
        if (h.hp <= 0) { target.dead = true; AudioSys.sfx('faint'); }
      }
    } else if (sk.type === 'drain') {
      let dmg = Math.max(1, Math.floor((eAtk*1.8 - st.def) * sk.power * rand(.9,1.1)));
      h.hp = clamp(h.hp - dmg, 0, h.maxHp);
      target.hurtT = .35;
      e.hp = clamp(e.hp + Math.floor(dmg*0.6), 0, e.maxHp);
      this.popup(target, dmg+'', '#b06ee8');
      this.castEffect('dark', target.x+16, target.y+10);
      AudioSys.sfx('dark');
      if (h.hp <= 0) { target.dead = true; AudioSys.sfx('faint'); }
    } else if (sk.type === 'debuff') {
      const map = { atk:'ATQ', def:'DEF', mag:'MAG', agi:'AGI', all:'TODAS' };
      if (sk.target === 'enemies') {
        // debilidad en área contra todo el grupo (Telaraña, Aullido, Maldición...)
        this.aliveParty().forEach(p => {
          p.hero.buffs = p.hero.buffs || {};
          p.hero.buffs[sk.stat] = { mult: sk.mult, turns: sk.turns };
          this.popup(p, '▼ ' + (map[sk.stat]||'?'), '#e08aff');
        });
      } else {
        target.hero.buffs = target.hero.buffs || {};
        target.hero.buffs[sk.stat] = { mult: sk.mult, turns: sk.turns };
        this.popup(target, '▼ ' + (map[sk.stat]||'?'), '#e08aff');
      }
      AudioSys.sfx('dark');
    } else if (sk.type === 'restore') {
      // enemigo se cura o cura aliado
      const tgt = e;
      tgt.hp = clamp(tgt.hp + sk.value, 0, tgt.maxHp);
      this.popup(tgt, '+'+sk.value, '#8ff0a0');
      AudioSys.sfx('heal');
    }
  },

  magicHitEnemy(e, target, sk) {
    const h = target.hero, st = statsOf(h);
    let dmg = Math.max(1, Math.floor((e.mag*2.2 - st.mag*0.4) * sk.power * rand(.9,1.1)));
    h.hp = clamp(h.hp - dmg, 0, h.maxHp);
    target.hurtT = .35;
    this.popup(target, dmg+'', '#e08aff');
    this.castEffect(sk.anim, target.x+16, target.y+10);
    if (h.hp <= 0) { target.dead = true; AudioSys.sfx('faint'); }
  },

  applyAoeHit(a) {
    const sk = SKILLS[a.skill];
    const attacker = a.who;
    const st = statsOf(attacker.hero);
    this.aliveEnemies().forEach(tgt => {
      let dmg;
      if (sk.type==='phys') dmg = Math.max(1, Math.floor((st.atk*2 - enemyStat(tgt,'def')) * sk.power * rand(.9,1.1)));
      else dmg = Math.max(1, Math.floor((st.mag*2.2 - enemyStat(tgt,'mag')*.5) * sk.power * rand(.9,1.1)));
      const weak = sk.elem && tgt.weak===sk.elem;
      if (weak) dmg = Math.floor(dmg*1.5);
      tgt.hp = clamp(tgt.hp - dmg, 0, tgt.maxHp);
      tgt.hurtT = .35;
      this.popup(tgt, dmg+'', weak?'#ff9e5e':'#fff');
      if (tgt.hp <= 0) { tgt.dead = true; G.monstersSlain++; this.popup(tgt,'¡Derrotado!','#ffd75e'); }
    });
    this.flashT = 0.15; this.shake = 10;
    AudioSys.sfx((({fire:'fire',ice:'ice',thunder:'thunder',holy:'holy',dark:'dark'})[sk.elem])||'hit');
  },

  endTurn() {
    // decrementar buffs del actor (héroes: hero.buffs · enemigos: enemy.buffs)
    const actorRef = this.actor?.ref;
    const bref = actorRef ? (actorRef.hero || actorRef) : null;
    if (bref && bref.buffs) {
      for (const k of Object.keys(bref.buffs)) {
        bref.buffs[k].turns--;
        if (bref.buffs[k].turns <= 0) delete bref.buffs[k];
      }
    }
    // fases de jefe
    for (const e of this.aliveEnemies()) {
      if (e.boss && e.phases > e.phase && e.hp < e.maxHp * (1 - e.phase/e.phases)) {
        e.phase++;
        this.msg(`¡${e.name} se enfurece! Su poder aumenta...`);
        e.atk = Math.floor(e.atk*1.25); e.mag = Math.floor(e.mag*1.2);
      }
    }
    if (this.phase === 'defeat') return;
    if (this.aliveEnemies().length === 0) { this.victory(); return; }
    if (this.aliveParty().length === 0) { this.defeat(); return; }
    this.phase = 'msg';
    this.msgTimer = 0.35;
    setTimeout(() => { if (this.active && this.phase==='msg') this.nextTurn(); }, 420);
  },

  update(dt) {
    // animación de entrada de enemigos
    if (this.introT !== undefined && this.introT < 0.9) {
      this.introT += dt;
      const t = clamp(this.introT/0.75, 0, 1);
      const ease = 1 - Math.pow(1-t, 3);
      this.enemies.forEach(e => { e.x = lerp(e.baseX+900, e.baseX, ease); });
      this.party.forEach((p,i) => { p.x = lerp(620+i*78 + 500, 620+i*78, ease); });
    }
    // mensajes
    if (this.phase === 'msg') {
      this.msgTimer -= dt;
      if (this.msgTimer <= 0 && this.msgQueue.length) {
        this.msgQueue.shift();
        const nx = this.msgQueue[0];
        if (nx) this.msgTimer = nx.dur || 1.6;
        else this.nextTurn();
      }
    }
    if (this.phase === 'victory') {
      this.victoryT += dt;
      if (this.victoryT > 1.2 && !this.showedResults) {
        this.showedResults = true;
        UI.showVictory(this, () => { this.showedResults = false; this.finish(); });
      }
    }
    if (this.phase === 'defeat') {
      this.defeatT += dt;
      if (this.defeatT > 1.6) {
        this.active = false;
        G.state = 'gameover';
        UI.showGameOver();
      }
    }
    Particles.update(dt);
  },
};
